import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
} from '@ionic/react';

const Detalle: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Segunda página</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding">
        <h2>Información de la aplicación</h2>
        <p>
          Esta aplicación muestra una lista de cinco productos
          y un contador que utiliza useState.
        </p>

        <IonButton routerLink="/home" routerDirection="back">
          Volver al inicio
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Detalle;