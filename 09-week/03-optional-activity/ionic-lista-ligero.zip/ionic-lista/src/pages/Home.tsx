import { useState } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonButton,
} from '@ionic/react';

const Home: React.FC = () => {
  const [contador, setContador] = useState(0);

  const productos = [
    'Teclado',
    'Mouse',
    'Monitor',
    'Audífonos',
    'Cable USB',
  ];

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Mis productos</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding">
        <IonList>
          {productos.map((producto) => (
            <IonItem key={producto}>
              <IonLabel>{producto}</IonLabel>
            </IonItem>
          ))}
        </IonList>

        <h2>Contador: {contador}</h2>

        <IonButton
          onClick={() => setContador((valor) => valor + 1)}
        >
          Aumentar
        </IonButton>

        <IonButton
          color="medium"
          onClick={() => setContador(0)}
        >
          Reiniciar
        </IonButton>

        <IonButton
          expand="block"
          routerLink="/detalle"
          routerDirection="forward"
        >
          Ir a la segunda página
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Home;