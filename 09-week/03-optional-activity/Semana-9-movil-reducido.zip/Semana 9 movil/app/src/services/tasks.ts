export interface Task {
  id: number;
  title: string;
  description: string;
}

const API_URL = "http://localhost:3000/api/tasks";

async function request<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  let response: Response;

  try {
    response = await fetch(url, {
      ...options,
      signal: AbortSignal.timeout(10000)
    });
  } catch {
    throw new Error(
      "No se pudo conectar con la API. Comprueba que esté encendida."
    );
  }

  if (!response.ok) {
    const body = await response.json().catch(() => null);
    throw new Error(
      body?.message || "Ocurrió un error al consultar la API."
    );
  }

  return response.json();
}

export function getTasks(): Promise<Task[]> {
  return request<Task[]>(API_URL);
}

export function getTask(id: string): Promise<Task> {
  return request<Task>(`${API_URL}/${encodeURIComponent(id)}`);
}

export function createTask(
  title: string,
  description: string
): Promise<Task> {
  return request<Task>(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ title, description })
  });
}
