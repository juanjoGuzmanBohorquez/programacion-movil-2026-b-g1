import { useState } from "react";
import type { FormEvent } from "react";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonInput,
  IonTextarea,
  IonButton,
  IonText,
  IonSpinner,
  useIonViewWillEnter
} from "@ionic/react";
import { getTasks, createTask } from "../services/tasks";
import type { Task } from "../services/tasks";

const Home = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [listError, setListError] = useState("");
  const [formError, setFormError] = useState("");
  const [success, setSuccess] = useState("");

  async function loadTasks() {
    setLoading(true);
    setListError("");

    try {
      const data = await getTasks();
      setTasks(data);
    } catch (error) {
      setListError(
        error instanceof Error ? error.message : "Error al cargar."
      );
    } finally {
      setLoading(false);
    }
  }

  useIonViewWillEnter(() => {
    void loadTasks();
  });

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (saving) return;

    setFormError("");
    setSuccess("");

    if (!title.trim() || !description.trim()) {
      setFormError("Completa el título y la descripción.");
      return;
    }

    setSaving(true);

    try {
      const newTask = await createTask(
        title.trim(),
        description.trim()
      );

      setTasks((current) => [...current, newTask]);
      setTitle("");
      setDescription("");
      setSuccess("Tarea creada correctamente.");
    } catch (error) {
      setFormError(
        error instanceof Error ? error.message : "Error al guardar."
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Mis tareas</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding">
        <h2>Nueva tarea</h2>

        <form onSubmit={handleSubmit}>
          <IonInput
            label="Título"
            labelPlacement="stacked"
            placeholder="Ejemplo: Estudiar para el quiz"
            value={title}
            onIonInput={(event) => setTitle(event.detail.value ?? "")}
            disabled={saving}
            required
          />

          <IonTextarea
            label="Descripción"
            labelPlacement="stacked"
            placeholder="Escribe los detalles de la tarea"
            value={description}
            onIonInput={(event) =>
              setDescription(event.detail.value ?? "")
            }
            disabled={saving}
            autoGrow
            required
          />

          <IonButton
            expand="block"
            type="submit"
            disabled={saving}
            className="ion-margin-top"
          >
            {saving ? "Guardando..." : "Crear tarea"}
          </IonButton>

          {formError && (
            <IonText color="danger">
              <p role="alert">{formError}</p>
            </IonText>
          )}

          {success && (
            <IonText color="success">
              <p role="status">{success}</p>
            </IonText>
          )}
        </form>

        <h2>Lista de tareas</h2>

        <IonButton
          fill="outline"
          onClick={() => void loadTasks()}
          disabled={loading || saving}
        >
          Actualizar lista
        </IonButton>

        {loading && (
          <div className="ion-padding">
            <IonSpinner />
            <p>Cargando tareas...</p>
          </div>
        )}

        {listError && (
          <IonText color="danger">
            <p role="alert">{listError}</p>
          </IonText>
        )}

        {!loading && !listError && tasks.length === 0 && (
          <p>No hay tareas registradas.</p>
        )}

        <IonList>
          {tasks.map((task) => (
            <IonItem
              key={task.id}
              routerLink={`/tasks/${task.id}`}
              detail
            >
              <IonLabel>
                <h2>{task.title}</h2>
                <p>{task.description}</p>
              </IonLabel>
            </IonItem>
          ))}
        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default Home;
