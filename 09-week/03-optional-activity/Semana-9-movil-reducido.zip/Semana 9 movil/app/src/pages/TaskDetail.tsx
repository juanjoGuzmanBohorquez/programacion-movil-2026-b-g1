import { useState } from "react";
import { useParams } from "react-router-dom";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonBackButton,
  IonButton,
  IonText,
  IonSpinner,
  useIonViewWillEnter
} from "@ionic/react";
import { getTask } from "../services/tasks";
import type { Task } from "../services/tasks";

const TaskDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [task, setTask] = useState<Task | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadTask() {
    setLoading(true);
    setError("");
    setTask(null);

    try {
      if (!id) {
        throw new Error("Falta el identificador de la tarea.");
      }

      const data = await getTask(id);
      setTask(data);
    } catch (error) {
      setError(
        error instanceof Error ? error.message : "Error al cargar."
      );
    } finally {
      setLoading(false);
    }
  }

  useIonViewWillEnter(() => {
    void loadTask();
  }, [id]);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton defaultHref="/home" text="Volver" />
          </IonButtons>
          <IonTitle>Detalle de tarea</IonTitle>
        </IonToolbar>
      </IonHeader>

      <IonContent className="ion-padding">
        {loading && (
          <div>
            <IonSpinner />
            <p>Cargando detalle...</p>
          </div>
        )}

        {!loading && error && (
          <div>
            <IonText color="danger">
              <p role="alert">{error}</p>
            </IonText>
            <IonButton onClick={() => void loadTask()}>
              Reintentar
            </IonButton>
          </div>
        )}

        {!loading && task && (
          <div>
            <h1>{task.title}</h1>
            <p><strong>ID:</strong> {task.id}</p>
            <h2>Descripción</h2>
            <p style={{ whiteSpace: "pre-wrap" }}>
              {task.description}
            </p>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default TaskDetail;
