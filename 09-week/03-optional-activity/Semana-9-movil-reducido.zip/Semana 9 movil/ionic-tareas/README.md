# Task App — Ionic React + Express API

Week 9 activity for the Mobile Programming course.

## Description

This application allows users to list tasks, create a new task, and open a detail screen. Each task has an ID, a title, and a description.

## Technologies

- Ionic React
- TypeScript
- React Router
- Node.js
- Express
- CORS
- Fetch API

## Features

- List tasks from the API.
- Create tasks using a form.
- Validate required fields.
- Display loading and saving states.
- Show network and HTTP error messages.
- Open task details and navigate back to the list.
- Refresh the task list.

## Architecture

The project has an Express REST API and an Ionic React frontend.
The GET /api/tasks endpoint returns the task list in JSON format.
The POST /api/tasks endpoint receives a title and a description, validates both fields, and returns the created task with status 201.
The GET /api/tasks/:id endpoint returns a single task or status 404 when the task does not exist.
The frontend consumes these endpoints using fetch through the shared service in app/src/services/tasks.ts.
The Home screen uses useState to manage tasks, form inputs, loading states, and feedback messages.
After a successful POST request, the frontend adds the returned task to the list and clears the form.
React Router handles navigation from the list to the task detail screen using the task ID.
The service checks HTTP responses and handles connection failures and request timeouts.
Tasks are stored in server memory, so newly created tasks are lost when the API restarts.

## Main Files

| File | Purpose |
| --- | --- |
| api/index.js | Express API, validation, and in-memory tasks |
| app/src/services/tasks.ts | Shared fetch requests and error handling |
| app/src/pages/Home.tsx | Task list and creation form |
| app/src/pages/TaskDetail.tsx | Task detail screen |
| app/src/App.tsx | Application routes and Ionic setup |

## API Endpoints

Base URL: http://localhost:3000

| Method | Endpoint | Description | Success status |
| --- | --- | --- | --- |
| GET | /api/tasks | List all tasks | 200 |
| POST | /api/tasks | Create a task | 201 |
| GET | /api/tasks/:id | Get a task by ID | 200 |

POST request example:

```json
{
  "title": "Study Ionic",
  "description": "Review components and navigation."
}
```

Error responses include a JSON message:

- 400: missing or invalid fields, or malformed JSON.
- 404: task not found.
- 500: unexpected server error.

## Run Locally

Install Node.js and npm before running the project.

From the ionic-tareas folder, start the API in one terminal:

```bash
cd api
npm install
node index.js
```

The API runs at http://localhost:3000.
Open http://localhost:3000/api/tasks to view the task list.

From the ionic-tareas folder, start the frontend in another terminal:

```bash
cd app
npm install
npm run dev
```

Open the Local URL printed by Vite, usually http://localhost:5173.

Keep both terminals running while using the application.
The frontend is configured to access the API on the same computer through localhost.

## Build

From the app folder:

```bash
npm run build
```

The production files are generated in app/dist.

## Manual Verification

1. Start the API and frontend.
2. Confirm that the initial tasks appear.
3. Enter a title and a description, then create a task.
4. Confirm that the new task appears in the list.
5. Select a task and check its ID, title, and description.
6. Use the back button to return to the list.
7. Stop the API and refresh the list to check the connection error message.
8. Restart the API and refresh the list to recover.
9. Try submitting blank fields to check validation.

## Limitations

This academic project uses in-memory storage and does not include a database.
Restarting the API restores the two initial tasks.
