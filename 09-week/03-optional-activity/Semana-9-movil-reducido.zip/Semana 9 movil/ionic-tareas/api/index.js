const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Las tareas se guardan en memoria.
const tasks = [
  {
    id: 1,
    title: "Estudiar Ionic",
    description: "Repasar Ionic React."
  },
  {
    id: 2,
    title: "Practicar Express",
    description: "Crear una API con GET y POST."
  }
];

let nextId = 3;

// Consultar todas las tareas.
app.get("/api/tasks", (req, res) => {
  res.json(tasks);
});

// Consultar una tarea por ID.
app.get("/api/tasks/:id", (req, res) => {
  const id = Number(req.params.id);
  const task = tasks.find((item) => item.id === id);

  if (!task) {
    return res.status(404).json({
      message: "La tarea no existe."
    });
  }

  res.json(task);
});

// Crear una tarea.
app.post("/api/tasks", (req, res) => {
  const { title, description } = req.body || {};

  if (
    typeof title !== "string" ||
    typeof description !== "string" ||
    !title.trim() ||
    !description.trim()
  ) {
    return res.status(400).json({
      message: "Completa el título y la descripción."
    });
  }

  const newTask = {
    id: nextId++,
    title: title.trim(),
    description: description.trim()
  };

  tasks.push(newTask);
  res.status(201).json(newTask);
});

// Manejar errores del servidor y JSON inválido.
app.use((error, req, res, next) => {
  if (error.type === "entity.parse.failed") {
    return res.status(400).json({
      message: "El JSON enviado no es válido."
    });
  }

  console.error(error);
  res.status(500).json({
    message: "Ocurrió un error en el servidor."
  });
});

app.listen(PORT, () => {
  console.log("API ejecutándose en http://localhost:3000");
});
